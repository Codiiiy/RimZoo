﻿using RimWorld;
using Verse;
using HarmonyLib;
using System.Collections.Generic;

namespace RimZoo
{
    // Patch to modify which animals are allowed in standard pens (but NOT exhibit markers)
    [HarmonyPatch(typeof(CompAnimalPenMarker), "AcceptsToPen")]
    public static class Patch_AcceptsToPen
    {
        static bool Prefix(CompAnimalPenMarker __instance, Pawn animal, ref bool __result)
        {
            // If the instance is a CompExhibitMarker, allow normal behavior
            if (__instance is CompExhibitMarker)
            {
                return true; // Run original method
            }

            // Only allow animals that are Roamer AND FenceBlocked
            if (animal.def.race.Roamer && animal.def.race.FenceBlocked)
            {
                __result = __instance.AnimalFilter.Allows(animal) && AnimalPenUtility.GetFixedAnimalFilter().Allows(animal);
                return false; // Skip original method
            }

            // Disallow non-roamer animals
            __result = false;
            return false; // Skip original method
        }
    }

    // Patch to modify the filter UI to HIDE non-roamer animals from standard pen markers
    [HarmonyPatch(typeof(CompAnimalPenMarker), "PostSpawnSetup")]
    public static class Patch_CompAnimalPenMarker_PostSpawnSetup
    {
        static void Postfix(CompAnimalPenMarker __instance)
        {
            // Do NOT modify exhibit markers
            if (__instance is CompExhibitMarker) return;

            // Remove all non-roamer animals from the filter
            List<ThingDef> toRemove = new List<ThingDef>();
            foreach (ThingDef def in __instance.AnimalFilter.AllowedThingDefs)
            {
                if (def.race == null || !def.race.Roamer || !def.race.FenceBlocked)
                {
                    toRemove.Add(def);
                }
            }

            // Apply the changes to remove non-roamers
            foreach (ThingDef def in toRemove)
            {
                __instance.AnimalFilter.SetAllow(def, false);
            }

            // **Force the UI to refresh**
            __instance.AnimalFilter.DisplayRootCategory = null; // This forces recalculation
        }
    }
}
