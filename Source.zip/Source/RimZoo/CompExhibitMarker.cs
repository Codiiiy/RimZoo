﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using static RimZoo.RimZoomain;
using static Verse.PenFoodCalculator;

namespace RimZoo
{
    public class CompExhibitMarker : CompAnimalPenMarker
    {
        private PenFoodCalculator CachedFoodCalculator
        {
            get
            {
                FieldInfo field = typeof(CompAnimalPenMarker)
                    .GetField("cachedFoodCalculator", BindingFlags.Instance | BindingFlags.NonPublic);
                return field?.GetValue(this) as PenFoodCalculator;
            }
        }

        public List<PenAnimalInfo> ExhibitAnimalsInfos =>
            CachedFoodCalculator != null ? CachedFoodCalculator.ActualAnimalInfos : new List<PenAnimalInfo>();

        public ThingDef selectedAnimal;

        public float Rarity
        {
            get
            {
                if (selectedAnimal == null)
                    return 0f;
                return selectedAnimal.GetStatValueAbstract(StatDefOf.MarketValue);
            }
        }

        public float Happiness
        {
            get
            {
                if (parent?.Map == null || selectedAnimal == null)
                    return 0f;
                IEnumerable<IntVec3> penCells = GetAutoCutCells();
                List<Pawn> pawns = new List<Pawn>();
                foreach (var cell in penCells)
                {
                    var cellPawns = cell.GetThingList(parent.Map)
                        .OfType<Pawn>()
                        .Where(p => p.def == selectedAnimal);
                    pawns.AddRange(cellPawns);
                }
                if (!pawns.Any())
                    return 0f;
                float penRating = GetPenRating();
                float totalHappiness = 0f;
                foreach (var pawn in pawns)
                {
                    float healthPct = pawn.health.summaryHealth.SummaryHealthPercent;
                    float foodPct = pawn.needs?.food?.CurLevelPercentage ?? 0f;
                    float pawnHappiness = (healthPct * 0.50f) + (foodPct * 0.25f) + (penRating * 0.25f);
                    totalHappiness += pawnHappiness;
                }
                return totalHappiness / pawns.Count;
            }
        }

        public int AssignedPawnCount
        {
            get
            {
                if (parent?.Map == null || selectedAnimal == null)
                    return 0;
                IEnumerable<IntVec3> penCells = GetAutoCutCells();
                List<Pawn> pawns = new List<Pawn>();
                foreach (var cell in penCells)
                {
                    var cellPawns = cell.GetThingList(parent.Map)
                        .OfType<Pawn>()
                        .Where(p => p.def == selectedAnimal);
                    pawns.AddRange(cellPawns);
                }
                return pawns.Count;
            }
        }

        private float GetPenRating()
        {
            if (CachedFoodCalculator == null)
                return 0f;
            if (CachedFoodCalculator.Unenclosed)
                return 0f;
            if (CachedFoodCalculator.numCellsSoil < 50)
                return 0.25f;
            if (CachedFoodCalculator.numCellsSoil < 100)
                return 0.5f;
            if (CachedFoodCalculator.numCellsSoil < 400)
                return 0.75f;
            return 1.0f;
        }

        private string GetHappinessBreakdown()
        {
            if (parent?.Map == null || selectedAnimal == null)
                return "No data";
            IEnumerable<IntVec3> penCells = GetAutoCutCells();
            List<Pawn> pawns = new List<Pawn>();
            foreach (var cell in penCells)
            {
                var cellPawns = cell.GetThingList(parent.Map)
                    .OfType<Pawn>()
                    .Where(p => p.def == selectedAnimal);
                pawns.AddRange(cellPawns);
            }
            if (!pawns.Any())
                return "No animals";
            float avgHealth = pawns.Average(p => p.health.summaryHealth.SummaryHealthPercent);
            float avgFood = pawns.Average(p => p.needs?.food?.CurLevelPercentage ?? 0f);
            float penRating = GetPenRating();
            float overall = (avgHealth * 0.50f) + (avgFood * 0.25f) + (penRating * 0.25f);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Overall Happiness: {overall:F2}");
            sb.AppendLine($"Health (50%): {avgHealth:F2}");
            sb.AppendLine($"Food (25%): {avgFood:F2}");
            sb.AppendLine($"Pen Size (25%): {penRating:F2}");
            return sb.ToString();
        }

        public override void PostSpawnSetup(bool respawningAfterLoad)
        {
            base.PostSpawnSetup(respawningAfterLoad);
            if (selectedAnimal == null)
            {
                selectedAnimal = ThingDefOf.Thrumbo;
            }
            RimZooMain.AllPens.Add(this);
            ForceDisplayedAnimalDefs.Clear();
            AnimalFilter.SetDisallowAll();
            ForceDisplayedAnimalDefs.Add(selectedAnimal);
            AnimalFilter.SetAllow(selectedAnimal, true);
        }

        public override void PostDeSpawn(Map map)
        {
            base.PostDeSpawn(map);
            RimZooMain.AllPens.Remove(this);
        }

        public override IEnumerable<IntVec3> GetAutoCutCells()
        {
            return base.GetAutoCutCells();
        }

        public override string CompInspectStringExtra()
        {
            StringBuilder sb = new StringBuilder(base.CompInspectStringExtra());
            sb.AppendLine();
            sb.Append("Selected Animal: ");
            sb.Append(selectedAnimal != null ? selectedAnimal.label : "None");
            sb.AppendLine();
            sb.Append("Rarity: ");
            sb.Append(Rarity.ToString("F2"));
            sb.AppendLine();
            sb.Append("Happiness: ");
            sb.Append(Happiness.ToString("F2"));
            sb.AppendLine();
            sb.Append("Pawn Count: ");
            sb.Append(AssignedPawnCount);
            sb.AppendLine();
            sb.AppendLine("Happiness Breakdown:");
            sb.Append(GetHappinessBreakdown());
            return sb.ToString().Trim();
        }

        public void ToggleSelectAnimal(ThingDef newAnimal)
        {
            selectedAnimal = newAnimal;
            ForceDisplayedAnimalDefs.Clear();
            AnimalFilter.SetDisallowAll();
            ForceDisplayedAnimalDefs.Add(selectedAnimal);
            AnimalFilter.SetAllow(selectedAnimal, true);
            CachedFoodCalculator?.ResetAndProcessPen(this);
        }

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            yield return new Command_Action
            {
                defaultLabel = "Select Animal",
                icon = ContentFinder<Texture2D>.Get("UI/Icons/ExhibitToggle", true),
                action = OpenSpeciesSelectionMenu
            };
            ToggleSelectAnimal(selectedAnimal);
        }

        private void OpenSpeciesSelectionMenu()
        {
            List<FloatMenuOption> options = DefDatabase<ThingDef>.AllDefs
                .Where(d => d.race?.Animal == true && !d.IsCorpse)
                .OrderBy(d => d.label)
                .Select(def => new FloatMenuOption(def.label, () => ToggleSelectAnimal(def)))
                .ToList();
            Find.WindowStack.Add(new FloatMenu(options));
        }
    }
}
