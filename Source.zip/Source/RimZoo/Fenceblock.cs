﻿using HarmonyLib;
using RimWorld;
using RimZoo;
using Verse;

[HarmonyPatch(typeof(Thing), "BlocksPawn")]
public static class Patch_BlocksPawn
{
    static void Postfix(Thing __instance, Pawn p, ref bool __result)
    {
        // Skip patch if the pawn is currently being roped.
        if (p?.CurJob != null && p.CurJob.def.defName.ToLowerInvariant().Contains("rope"))
        {
            return;
        }

        if (__result) return; // Already blocked, no need to proceed.
        if (p == null || __instance == null) return;

        // Check if it's a gate (Building_Door) and block the animal if it's closed.
        if (__instance is Building_Door door)
        {
            if (!door.Open) // Only block if the gate is closed.
            {
                __result = true;
                return;
            }
        }

        // Check if the current thing has a CompExhibitMarker.
        CompExhibitMarker comp = __instance.TryGetComp<CompExhibitMarker>();
        if (comp != null && comp.selectedAnimal == p.def)
        {
            __result = true;
            return;
        }

        // Otherwise, check for any exhibit marker on the map with the selected animal.
        Map map = __instance.Map;
        if (map != null)
        {
            foreach (Building building in map.listerBuildings.allBuildingsColonist)
            {
                CompExhibitMarker markerComp = building.TryGetComp<CompExhibitMarker>();
                if (markerComp != null && markerComp.selectedAnimal == p.def)
                {
                    __result = true;
                    return;
                }
            }
        }

    }
    [HarmonyPatch(typeof(Building_Door), "PawnCanOpen")]
    public static class Patch_PawnCanOpen
    {
        static void Postfix(Building_Door __instance, Pawn p, ref bool __result)
        {
            if (p == null || __instance == null) return;

            // Check if the animal is in any exhibit marker on the map
            Map map = __instance.Map;
            if (map != null)
            {
                foreach (Building building in map.listerBuildings.allBuildingsColonist)
                {
                    CompExhibitMarker markerComp = building.TryGetComp<CompExhibitMarker>();
                    if (markerComp != null && markerComp.selectedAnimal == p.def)
                    {
                        __result = false; // Prevent this animal from opening gates
                        return;
                    }
                }
            }
        }
    }
}