﻿using Verse;
using UnityEngine;
using HarmonyLib;

namespace RimZoo
{
    public class RimZoomain : Mod
    {
        public static RimZoomainSettings settings;

        public RimZoomain(ModContentPack content) : base(content)
        {
            settings = GetSettings<RimZoomainSettings>();
            var harmony = new Harmony("com.rimzoo.exhibitharmonypatch");
            harmony.PatchAll();
        }

        public override string SettingsCategory()
        {
            return "RimZoo";
        }

        public override void DoSettingsWindowContents(Rect inRect)
        {
            settings.DoWindowContents(inRect);
        }
    }
}
