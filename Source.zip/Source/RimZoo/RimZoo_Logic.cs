﻿using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;

namespace RimZoo
{
    public static class RimZooMain
    {
        public static float global_Happiness = 0f;
        public static float total_Rarity = 0f;
        public static float Rating = 0f;
        public static float Variety = 0f;
        public static float Price = 0f;
        public static float scaled_Rating;
        public static List<CompExhibitMarker> AllPens = new List<CompExhibitMarker>();

        public static void UpdateRates()
        {
            if (AllPens.Count > 0)
                global_Happiness = AllPens.Sum(p => p.Happiness) / AllPens.Count;
            else
                global_Happiness = 0f;

            Variety = AllPens.Select(p => p.selectedAnimal?.defName)
                             .Where(defName => defName != null)
                             .Distinct()
                             .Count();
            total_Rarity = AllPens.Sum(p => p.Rarity);
            Rating = Variety * total_Rarity * global_Happiness;
            scaled_Rating = Mathf.Clamp((Rating / 20000f) * 4.9f + 0.1f, 0.1f, 5f);
            Price = RimZoomain.settings.priceMultiplier * (50 + ((scaled_Rating - 0.1f) / (5f - 0.1f)) * 200);
        }
    }

    public static class ExhibitAnimalTracker
    {
        public static HashSet<Pawn> ExhibitAnimals = new HashSet<Pawn>();
        [System.ThreadStatic]
        public static Pawn CurrentPawn;
    }
}
