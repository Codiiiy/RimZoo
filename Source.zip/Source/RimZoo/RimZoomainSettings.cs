﻿using Verse;
using UnityEngine;

namespace RimZoo
{
    public class RimZoomainSettings : ModSettings
    {
        public float priceMultiplier = 1.0f;

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref priceMultiplier, "priceMultiplier", 1.0f);
        }

        public void DoWindowContents(Rect inRect)
        {
            float curY = inRect.y;
            Widgets.Label(new Rect(inRect.x, curY, inRect.width, 30), "RimZoo Settings");
            curY += 40;
            Widgets.Label(new Rect(inRect.x, curY, inRect.width, 30), "Price Multiplier: " + priceMultiplier.ToString("F2"));
            curY += 30;
            priceMultiplier = Widgets.HorizontalSlider(new Rect(inRect.x, curY, inRect.width, 30), priceMultiplier, 0.1f, 5.0f, false);
        }
    }
}
