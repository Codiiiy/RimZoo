﻿using RimWorld;
using UnityEngine;
using Verse;

namespace RimZoo
{
    public class Dialog_RimZoo : Window
    {
        public override Vector2 InitialSize => new Vector2(700f, 500f);

        public Dialog_RimZoo()
        {
            forcePause = true;
            doCloseButton = true;
            absorbInputAroundWindow = true;
        }

        public override void DoWindowContents(Rect inRect)
        {
            RimZooMain.UpdateRates();
            float y = 10f;
            Rect globalRect = new Rect(10, y, inRect.width - 20, 40);
            GUI.BeginGroup(globalRect);
            float x = 10f;
            float labelWidth = (globalRect.width - 20) / 4f;
            Widgets.Label(new Rect(x, 5, labelWidth, 30), $"Happiness: {RimZooMain.global_Happiness:F2}");
            x += labelWidth;
            Widgets.Label(new Rect(x, 5, labelWidth, 30), $"Variety: {RimZooMain.Variety}");
            x += labelWidth;
            Widgets.Label(new Rect(x, 5, labelWidth, 30), $"Scaled Rating: {RimZooMain.scaled_Rating:F2}");
            x += labelWidth;
            Widgets.Label(new Rect(x, 5, labelWidth, 30), $"Price: {RimZooMain.Price:F2}");
            GUI.EndGroup();
            y += globalRect.height + 10f;

            foreach (var pen in RimZooMain.AllPens)
            {
                string exhibitName = pen.selectedAnimal?.defName ?? "No animal assigned";
                string exhibitInfo = $"Species: {exhibitName}, Happiness: {pen.Happiness:F2}, Rarity: {pen.Rarity:F2}";
                Rect exhibitRect = new Rect(10, y, inRect.width - 20, 30);
                Widgets.DrawMenuSection(exhibitRect); // Optional: You can keep this for section borders
                if (Widgets.ButtonInvisible(exhibitRect))
                {
                    JumpToExhibit(pen);
                }
                Widgets.Label(new Rect(exhibitRect.x + 5, exhibitRect.y + 5, exhibitRect.width - 10, exhibitRect.height - 10), exhibitInfo);
                y += exhibitRect.height + 5;
            }
        }

        private void JumpToExhibit(CompExhibitMarker pen)
        {
            if (pen?.parent?.Position != null)
            {
                CameraJumper.TryJumpAndSelect(pen.parent);
            }
        }
    }
}
