﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using static Verse.PenFoodCalculator;

namespace RimZoo
{
    public class CompExhibitMarker : CompAnimalPenMarker
    {
        public PenFoodCalculator ExhibitFoodCalculator;
        public ThingDef selectedAnimal;

        public List<PenAnimalInfo> ExhibitAnimalsInfos => ExhibitFoodCalculator.ActualAnimalInfos;

        // New public property for Rarity.
        // It computes the average market value (marketValue comes from the animal's ThingDef)
        // across all animals in the exhibit.
        public float Rarity
        {
            get
            {
                if (ExhibitAnimalsInfos == null || !ExhibitAnimalsInfos.Any())
                    return 0f;

                float totalWorth = 0f;
                int count = 0;
                foreach (var info in ExhibitAnimalsInfos)
                {
                    // Assumes that each PenAnimalInfo holds a reference to the animal Pawn.
                    Pawn pawn = info.pawn;
                    if (pawn != null && pawn.def != null)
                    {
                        totalWorth += pawn.def.marketValue;
                        count++;
                    }
                }
                return count > 0 ? totalWorth / count : 0f;
            }
        }

        // New public property for Happiness.
        // It computes an average happiness value using each pawn’s health percentage 
        // (obtained from pawn.health.summaryHealth.SummaryHealthPercent) multiplied 
        // by its current food level (from pawn.needs.food.CurLevelPercentage).
        public float Happiness
        {
            get
            {
                if (ExhibitAnimalsInfos == null || !ExhibitAnimalsInfos.Any())
                    return 0f;

                float totalHappiness = 0f;
                int count = 0;
                foreach (var info in ExhibitAnimalsInfos)
                {
                    Pawn pawn = info.pawn;
                    if (pawn != null)
                    {
                        float healthPct = pawn.health.summaryHealth.SummaryHealthPercent;
                        float foodPct = pawn.needs?.food?.CurLevelPercentage ?? 0f;
                        totalHappiness += healthPct * foodPct;
                        count++;
                    }
                }
                return count > 0 ? totalHappiness / count : 0f;
            }
        }

        public override void PostSpawnSetup(bool respawningAfterLoad)
        {
            base.PostSpawnSetup(respawningAfterLoad);

            // If no species has been selected, default to a common animal (e.g., Cow).
            if (selectedAnimal == null)
            {
                selectedAnimal = ThingDefOf.Cow;
            }

            // Ensure that only the selected animal is force-displayed.
            ForceDisplayedAnimalDefs.Clear();
            AnimalFilter.SetDisallowAll();
            ForceDisplayedAnimalDefs.Add(selectedAnimal);
            AnimalFilter.SetAllow(selectedAnimal, true);
        }

        public override IEnumerable<IntVec3> GetAutoCutCells()
        {
            // Use base functionality for auto-cut cells, which will use the game’s roping/pen functions.
            return base.GetAutoCutCells();
        }

        public override string CompInspectStringExtra()
        {
            // Start with the base inspect string.
            StringBuilder sb = new StringBuilder(base.CompInspectStringExtra());
            sb.AppendLine();
            sb.Append("Selected Animal: ");
            sb.Append(selectedAnimal != null ? selectedAnimal.label : "None");
            sb.AppendLine();
            sb.Append("Rarity: ");
            sb.Append(Rarity.ToString("F2"));
            sb.AppendLine();
            sb.Append("Happiness: ");
            sb.Append(Happiness.ToString("F2"));
            return sb.ToString();
        }

        public void ToggleSelectAnimal(ThingDef newAnimal)
        {
            // Only allow one species.
            selectedAnimal = newAnimal;
            ForceDisplayedAnimalDefs.Clear();
            AnimalFilter.SetDisallowAll();
            ForceDisplayedAnimalDefs.Add(selectedAnimal);
            AnimalFilter.SetAllow(selectedAnimal, true);
        }

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            yield return new Command_Action
            {
                defaultLabel = "Select Animal",
                icon = ContentFinder<Texture2D>.Get("UI/Icons/ExhibitToggle", true),
                action = OpenSpeciesSelectionMenu
            };
            ToggleSelectAnimal(selectedAnimal);
        }

        private void OpenSpeciesSelectionMenu()
        {
            List<FloatMenuOption> options = DefDatabase<ThingDef>.AllDefs
                .Where(d => d.race?.Animal == true && !d.IsCorpse)
                .OrderBy(d => d.label)
                .Select(def => new FloatMenuOption(def.label, () => selectedAnimal = def))
                .ToList();

            Find.WindowStack.Add(new FloatMenu(options));
        }
    }
}
