﻿using RimWorld;
using Verse;

namespace RimZoo
{
    public class CompProperties_ExhibitMarker : CompProperties_AnimalPenMarker
    {
        public CompProperties_ExhibitMarker()
        {
            compClass = typeof(CompExhibitMarker);
        }
    }
}
