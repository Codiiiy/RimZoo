﻿using Verse;
using UnityEngine;
using RimZoo;
using HarmonyLib;
using System.Collections.Generic;

namespace RimZoo
{
    public class RimZoomain : Mod
    {
        public static RimZoomainSettings settings;

        public RimZoomain(ModContentPack content) : base(content)
        {
            settings = GetSettings<RimZoomainSettings>();
            var harmony = new Harmony("com.rimzoo.exhibitharmonypatch");
            harmony.PatchAll();
        }

        public override string SettingsCategory()
        {
            return "RimZoo";
        }

        public override void DoSettingsWindowContents(Rect inRect)
        {
            settings.DoWindowContents(inRect);
        }

        public static class RimZooMain
        {
            public static float guest_Rate = 5f;
            public static float Price = 0f;
            public static float global_Beauty = 0f;
            public static float global_happiness = 0f;
            public static float total_Rarity = 0f;
            public static float Rating = 0f;
            public static float Variety = 0f;

            public static void UpdateRates()
            {
                Price = Variety * total_Rarity;
                guest_Rate = Rating * global_happiness;
            }
        }

        public static class ExhibitAnimalTracker
        {
            public static HashSet<Pawn> ExhibitAnimals = new HashSet<Pawn>();

            [System.ThreadStatic]
            public static Pawn CurrentPawn;
        }
    }
}
