﻿using RimWorld;
using Verse;

namespace RimZoo
{
    [DefOf]
    public static class RimZoo_DefOf
    {
        public static MainButtonDef RimZoo;
    }
}
