﻿using Verse;
using UnityEngine;

namespace RimZoo
{
    public class RimZoomainSettings : ModSettings
    {
        // Add mod-specific settings here if needed

        public override void ExposeData()
        {
            base.ExposeData();
            // Save/load settings as necessary.
        }

        public void DoWindowContents(Rect inRect)
        {
            // Basic settings UI
            Widgets.Label(new Rect(inRect.x, inRect.y, inRect.width, 30), "RimZoo Settings");
            // You could add a toggle or dropdown here to choose default animal species, etc.
        }
    }
}
