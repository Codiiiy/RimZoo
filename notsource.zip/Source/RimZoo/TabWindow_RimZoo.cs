﻿using RimWorld;
using UnityEngine;
using Verse;

namespace RimZoo
{
    public class TabWindow_RimZoo : MainTabWindow
    {
        public override Vector2 InitialSize => new Vector2(700f, 500f);

        public override void DoWindowContents(Rect inRect)
        {
            Widgets.Label(new Rect(0, 0, 300, 30), "Welcome to RimZoo Management!");
            // Future UI elements will go here.
        }
    }
}
