﻿using RimWorld;
using Verse;
using HarmonyLib;

namespace RimZoo
{
    public static class ExhibitPenUtility
    {
        public static bool applyExhibitPenLogic = false;
    }

    [HarmonyPatch(typeof(AnimalPenUtility), "IsRopeManagedAnimalDef")]
    public static class Patch_IsRopeManagedAnimalDef
    {
        static bool Prefix(ThingDef td, ref bool __result)
        {
            if (td.race != null && td.IsWithinCategory(ThingCategoryDefOf.Animals))
            {
                __result = true;
                return false;
            }
            return true;
        }
    }

    [HarmonyPatch(typeof(AnimalPenUtility), "ShouldBePennedByDefault")]
    public static class Patch_ShouldBePennedByDefault
    {
        
        static bool Prefix(ThingDef td, ref bool __result)
        {
            if (td.race != null && td.IsWithinCategory(ThingCategoryDefOf.Animals))
            {
                __result = true;
                return false;
            }
            return true;
        }
    }
}